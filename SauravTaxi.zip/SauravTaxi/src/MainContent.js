export default function MainContent()
{
  return(
    <div>
    <div className="backg">
      <h1 className='hh'>Fun facts about React</h1>
        <ul className='oll'>
          <li>It's a popular Library</li>
          <li>  I'am more likly to get job.</li>
          <li>Was first release in 2013</li>
          <li>Was originally created by Jorden Walke</li>
          <li>Has well over 100k stars on Github</li>
          <li>Is maintained by Facebook</li>
        </ul>
    </div>
  </div>
  )
}