import React from 'react'

function Footer() {
  return (
    <div className='footer'>
      <p className='foot'>Copyright &copy; Maxi Taxi Perth | Website Design & SEO ByDigital Checkpoint.</p>
    </div>
  )
}

export default Footer
